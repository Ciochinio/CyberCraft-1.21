
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.rbm.cybercraft.init;

import org.lwjgl.glfw.GLFW;

import net.rbm.cybercraft.network.Test123Message;
import net.rbm.cybercraft.network.DoubleJumpMessage;
import net.rbm.cybercraft.network.CyberwareMenuMessage;
import net.rbm.cybercraft.CybercraftMod;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class CybercraftModKeyMappings {
	public static final KeyMapping CYBERWARE_MENU = new KeyMapping("key.cybercraft.cyberware_menu", GLFW.GLFW_KEY_F8, "key.categories.cybercraft") {
		private boolean isDownOld = false;

		@Override
		public void setDown(boolean isDown) {
			super.setDown(isDown);
			if (isDownOld != isDown && isDown) {
				CybercraftMod.PACKET_HANDLER.sendToServer(new CyberwareMenuMessage(0, 0));
				CyberwareMenuMessage.pressAction(Minecraft.getInstance().player, 0, 0);
			}
			isDownOld = isDown;
		}
	};
	public static final KeyMapping DOUBLE_JUMP = new KeyMapping("key.cybercraft.double_jump", GLFW.GLFW_KEY_SPACE, "key.categories.cybercraft") {
		private boolean isDownOld = false;

		@Override
		public void setDown(boolean isDown) {
			super.setDown(isDown);
			if (isDownOld != isDown && isDown) {
				CybercraftMod.PACKET_HANDLER.sendToServer(new DoubleJumpMessage(0, 0));
				DoubleJumpMessage.pressAction(Minecraft.getInstance().player, 0, 0);
			}
			isDownOld = isDown;
		}
	};
	public static final KeyMapping TEST_123 = new KeyMapping("key.cybercraft.test_123", GLFW.GLFW_KEY_F9, "key.categories.misc") {
		private boolean isDownOld = false;

		@Override
		public void setDown(boolean isDown) {
			super.setDown(isDown);
			if (isDownOld != isDown && isDown) {
				CybercraftMod.PACKET_HANDLER.sendToServer(new Test123Message(0, 0));
				Test123Message.pressAction(Minecraft.getInstance().player, 0, 0);
			}
			isDownOld = isDown;
		}
	};

	@SubscribeEvent
	public static void registerKeyMappings(RegisterKeyMappingsEvent event) {
		event.register(CYBERWARE_MENU);
		event.register(DOUBLE_JUMP);
		event.register(TEST_123);
	}

	@Mod.EventBusSubscriber({Dist.CLIENT})
	public static class KeyEventListener {
		@SubscribeEvent
		public static void onClientTick(TickEvent.ClientTickEvent event) {
			if (Minecraft.getInstance().screen == null) {
				CYBERWARE_MENU.consumeClick();
				DOUBLE_JUMP.consumeClick();
				TEST_123.consumeClick();
			}
		}
	}
}
