
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.rbm.cybercraft.init;

import net.rbm.cybercraft.CybercraftMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class CybercraftModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, CybercraftMod.MODID);
	public static final RegistryObject<CreativeModeTab> CYBER_CRAFT_TAB = REGISTRY.register("cyber_craft_tab",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.cybercraft.cyber_craft_tab")).icon(() -> new ItemStack(Blocks.REDSTONE_TORCH)).displayItems((parameters, tabData) -> {
				tabData.accept(CybercraftModItems.REINFORCED_TENDONS.get());
				tabData.accept(CybercraftModItems.FORTIFIED_ANKLES.get());
				tabData.accept(CybercraftModItems.LYNX_PAWS.get());
				tabData.accept(CybercraftModItems.LEEROY_LIGAMENT_SYSTEM.get());
				tabData.accept(CybercraftModItems.NANO_PLATING.get());
				tabData.accept(CybercraftModItems.PAINDUCER.get());
				tabData.accept(CybercraftModItems.COUNTERSHELL.get());
				tabData.accept(CybercraftModItems.PAIN_EDITOR.get());
				tabData.accept(CybercraftModItems.PROXISHIELD.get());
				tabData.accept(CybercraftModItems.RANGEGUARD.get());
				tabData.accept(CybercraftModItems.SUBDERMAL_ARMOR.get());
				tabData.accept(CybercraftModItems.CHITIN.get());
				tabData.accept(CybercraftModItems.SHOCK_N_AWE.get());
				tabData.accept(CybercraftModItems.THREATEVAC.get());
				tabData.accept(CybercraftModItems.SECOND_HEART.get());
				tabData.accept(CybercraftModItems.MICROROTORS.get());
				tabData.accept(CybercraftModItems.HEAL_ON_KILL.get());
				tabData.accept(CybercraftModItems.ADRENALINE_BOOSTER.get());
				tabData.accept(CybercraftModItems.BLACK_MAMBA.get());
				tabData.accept(CybercraftModItems.ISOMETRIC_STABILIZER.get());
				tabData.accept(CybercraftModItems.BIOMONITOR.get());
				tabData.accept(CybercraftModItems.ADRENALINE_CONVERTER.get());
				tabData.accept(CybercraftModItems.ATOMIC_SENSORS.get());
				tabData.accept(CybercraftModItems.DEEPFIELD_VISUAL_INTERFACE.get());
				tabData.accept(CybercraftModItems.STABBER.get());
				tabData.accept(CybercraftModItems.NEOFIBER.get());
				tabData.accept(CybercraftModItems.TYROSINE_INJECTOR.get());
				tabData.accept(CybercraftModItems.HANDGUN_AMMO.get());
				tabData.accept(CybercraftModItems.NBGHFVC.get());
				tabData.accept(CybercraftModItems.BIONIC_JOINTS.get());
				tabData.accept(CybercraftModItems.DENSE_MARROW.get());
				tabData.accept(CybercraftModItems.EPIMORPHIC_SKELETON.get());
			})

					.build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {

		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(CybercraftModItems.LAPKI_CHESTPLATE.get());
		}
	}
}
